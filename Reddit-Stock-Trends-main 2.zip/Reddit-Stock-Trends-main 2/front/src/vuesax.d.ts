declare module 'vuesax';
