<template>
  <router-view />
</template>

<style lang="scss">
body {
  background-color: var(--surface-a) !important;
  margin: 0;
  font-family: var(--font-family);
  font-weight: 400;
  color: var(--text-color) !important;
}
</style>
